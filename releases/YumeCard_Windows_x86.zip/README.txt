YumeCard Windows x86 版本 
 
使用方法: 
  YumeCard_x86.exe --help    显示帮助 
  YumeCard_x86.exe system-info    显示系统信息 
 
构建时间: 周六 2025/05/31  0:26:04.53 
